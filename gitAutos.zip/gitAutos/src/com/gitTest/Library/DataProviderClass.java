package com.gitTest.Library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DataProviderClass 
{

	@DataProvider(name = "excel-data-provider")
	public static Object[][] readData() throws IOException
	{
		File file=new File(System.getProperty("user.dir")+"\\src\\test\\java\\com\\gitTest\\InputFiles\\LoginData.xlsx");
		FileInputStream filestr=new FileInputStream(file);
		XSSFWorkbook excelFile=new XSSFWorkbook(filestr);
		XSSFSheet loginSheet=excelFile.getSheet("Login");
		Object[][] InputData=new Object[2][3];
		InputData[0][0]=loginSheet.getRow(1).getCell(0).getStringCellValue();
		InputData[0][1]=loginSheet.getRow(1).getCell(1).getStringCellValue();
		InputData[0][2]=loginSheet.getRow(1).getCell(2).getStringCellValue();
		InputData[1][0]=loginSheet.getRow(2).getCell(0).getStringCellValue();
		InputData[1][1]=loginSheet.getRow(2).getCell(1).getStringCellValue();
		InputData[1][2]=loginSheet.getRow(2).getCell(2).getStringCellValue();
		return InputData;
		
		
	}
}
