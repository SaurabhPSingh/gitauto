package com.gitTest.Library;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.gitTest.Page.LoginPage;
import com.gitTest.TestImplementation.LoginImplementation;

public class CommonLibrary 
{
	Properties properties;
	public WebDriver OpenChromeGetURL(String URL)
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(URL);
		return driver;
		
	}
	
	public String readData(String propName,String fileName) throws FileNotFoundException , IOException
	{
		properties=new Properties();
		File inputFile=new File(System.getProperty("user.dir")+"\\src\\com\\gitTest\\InputFiles\\"+fileName);
		FileReader fileRdr=new FileReader(inputFile);
		properties.load(fileRdr);
		String propValue=properties.getProperty(propName);
		return propValue;
				
	}

	public ArrayList<String> readDataTabSeparated(String fileName) throws IOException
	{
		ArrayList<String> inputList=new ArrayList<String>();
		File file=new File(System.getProperty("user.dir")+"\\src\\test\\java\\com\\gitTest\\InputFiles\\"+fileName);
		FileInputStream  FInStream=new FileInputStream(file);
		InputStreamReader ISR=new InputStreamReader(FInStream);
		BufferedReader bfr=new BufferedReader(ISR);
		//System.out.println(bfr.readLine());
		String line;
		while((line=bfr.readLine()) !=null)
		{
			System.out.println("line----"+line);
			String[] aniList=null;
			aniList=line.split("\t");
			inputList.add(aniList[0]);
			inputList.add(aniList[1]);
		}
		System.out.println(inputList);
		FInStream.close();
		ISR.close();
		bfr.close();
		return inputList;
	}
	
	public void scrollToWebElement(WebDriver driver,WebElement element) throws InterruptedException
	{
		JavascriptExecutor js= (JavascriptExecutor)driver;
		  js.executeScript("arguments[0].scrollIntoView(true);", element);
		  Thread.sleep(500);
	}

	public void scrollToElement(WebDriver driver,WebElement element)
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}
	
	public void loginToApplication(WebDriver driver) throws FileNotFoundException, InterruptedException, IOException
	{
		String inputFileName="LoginInput.properties";
		String email=readData("email",inputFileName);
		String passwrd=readData("password",inputFileName);
		LoginPage loginPage=new LoginPage(driver);
		loginPage.clickNavigateToSignInButton();
		loginPage.enterUserName(email);
		loginPage.enterPassword(passwrd);
		loginPage.clickSignInButton();
	}

}
