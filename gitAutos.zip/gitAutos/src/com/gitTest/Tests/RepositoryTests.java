package com.gitTest.Tests;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.gitTest.Library.CommonLibrary;
import com.gitTest.Library.DataProviderClass;
import com.gitTest.TestImplementation.RepoTestImplementation;

public class RepositoryTests extends RepoTestImplementation
{
WebDriver driver;


@BeforeMethod
public void beforeTest()
{
	CommonLibrary lib=new CommonLibrary();
	this.driver=lib.OpenChromeGetURL("https://www.github.com");
	
}


@Test(priority=1,enabled=true)
public void TC1CreateRepositoryTest() throws FileNotFoundException, IOException, InterruptedException
{

		Reporter.log("Executing Test Case ID -- 0001 Name: Verify Git Create Repo main flow.");
		CreateRepositoryTest(driver);
			
}


@Test(priority=2,dependsOnMethods = {"TC1CreateRepositoryTest"},enabled=true)
public void TC2CreateIssueTest() throws FileNotFoundException, IOException, InterruptedException
{
	
		Reporter.log("Executing Test Case ID -- 0002 Name: Verify Git Create Repo main flow.");
		CreateIssueTest(driver);
}


@Test(priority=3,dependsOnMethods = {"TC2CreateIssueTest"})
public void TC3DeleteRepositoryTest() throws FileNotFoundException, InterruptedException, IOException
{

		Reporter.log("Executing Test Case ID -- 0003 Name: Verify deletion of a Repository.");
		deleteRepositoryTest(driver);
			
}


@AfterMethod
public void afterTest()
{
	driver.close();
}
}
