package com.gitTest.Tests;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.gitTest.Library.CommonLibrary;
import com.gitTest.Library.DataProviderClass;
import com.gitTest.TestImplementation.LoginImplementation;

public class LoginTests extends LoginImplementation
{
	WebDriver driver;
	@BeforeMethod
	public void beforeTest()
	{
		CommonLibrary lib=new CommonLibrary();
		this.driver=lib.OpenChromeGetURL("https://www.github.com");
		
	}
	
	@Test(enabled=false,dataProvider = "excel-data-provider", dataProviderClass=DataProviderClass.class)
	public void TC1TestGitLogin(String email, String Password, String userName)
	{
		
		try
		{
			Reporter.log("Executing Test Case ID -- xxxx Name: Verify Git Login main flow.");
			gitLoginTest(driver,email,Password,userName);
			
		}
		catch(Exception e)
		{
			
			
			
		}
		
	}
	
	@AfterMethod
	public void afterTest()
	{
		//driver.close();
	}
}
