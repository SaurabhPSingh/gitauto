package com.gitTest.Page;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;

import com.gitTest.Library.CommonLibrary;

public class RepoTestPage extends CommonLibrary
{
	WebDriver driver;
	String inputFileName="RepoTestInputs.properties";
	
	String repoName;
	String issueTitle;
	String imageName;
	
	By createButton=By.xpath("//a[contains(@class,\"header-nav-link tooltipped\")]");
	By createRepositoryLink=By.xpath("//a[contains(text(),\"New repository\")]");
	By repoNameLocator=By.id("repository_name");
	By readMeCheckbox=By.id("repository_auto_init");
	By createRepoButton=By.xpath("//button[contains(text(),\"Create repository\")]");
	By createdRepositoryName=By.xpath("//strong[contains(@itemprop,\"name\")]/a");
	By repoSettingsButton=By.xpath("//a[contains(@data-selected-links,\"repo_settings \")]");
	By repoDeleteButton=By.xpath("//button[contains(text(),\"Delete this repository\")]");
	By createIssueDropDownBtn=By.xpath("//a[contains(text(),\"New issue\")]");
	By issueTitleLocator=By.id("issue_title");
	By inputImageFile=By.xpath("//input[contains(@aria-label,\"Attach files to your comment\")]");
	By submitIssueBtn=By.xpath("//button[contains(text(),\"Submit new issue\")]");
	By issueTextArea=By.xpath("//div[contains(@class,\"preview-content\")]/div[contains(@class,\"comment\")]//img");
	By newIssueTitle=By.xpath("//div[contains(@id,\"partial-discussion-header\")]//h1/span[contains(@class,\"js-issue-title\")]");
	By newIssueImage=By.xpath("//div[contains(@class,\"edit-comment-hide\")]//img");
	By repoListingName=By.xpath("//ul[contains(@id,\"repo_listing\")]//span");
	By previewButton=By.xpath("//button[contains(text(),\"Preview\")]");
	By repoDeletedMessage=By.xpath("//button[contains(@aria-label,\"Dismiss this message\")]/parent::div[contains(@class,\"container\")]");
	By confirmBox=By.xpath("//div[contains(@id,\"facebox\")]//input[contains(@name,\"verify\")]");
	By confirmButton=By.xpath("//div[contains(@id,\"facebox\")]//button[contains(text(),\"I understand the consequences\")]");
	
	
	public RepoTestPage(){}
	
	public RepoTestPage(WebDriver driver)
	{
		this.driver=driver;
	}

	public void clickCreateButton()
	{
		try
		{
		driver.findElement(createButton).click();
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test Failed as the Create button not present");
		}
	}
	
	public void clickCreateRepoLink()
	{
		try
		{
		driver.findElement(createRepositoryLink).click();
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test Failed as the Create button not present");
		}
	}
		
	public void enterRepositoryName(String repNameProperty) throws FileNotFoundException, IOException
	{
		try
		{
		String repoNameInput=readData(repNameProperty,inputFileName);
		this.repoName=repoNameInput;
		driver.findElement(repoNameLocator).sendKeys(repoNameInput);
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test Failed as the Repo Name field not present");
		}
	}
	
	public boolean verifyIfRepoNameAccepted()
	{
		boolean result=false;
		try
		{
			WebElement repName=driver.findElement(repoNameLocator);
			if(repName.getAttribute("data-autocheck-url").equals("/repositories/check-name"))
					{
					Reporter.log("Repo Name validation sign present");
					result=true;
					}
			else
					{
					Reporter.log("Test Failed as Repo Name validation sign not present");
					result=false;
					}
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test Failed as the Repo Name field not present");
			return false;
		}
		return result;
	}

	public void checkInitializeWithReadMeCheckBox() throws InterruptedException
	{
		try
		{
			scrollToWebElement(driver,driver.findElement(readMeCheckbox));
			driver.findElement(readMeCheckbox).click();;
		}
		catch(NoSuchElementException NSEE)
		{
		Reporter.log("Test Failed as Intialize with readme file checkbox not present");
		}
	}

	public void clickTheCreateRepositoryButton()
	{
		try
		{
			driver.findElement(createRepoButton).click();
		}
		catch(NoSuchElementException NSEE)
		{
		Reporter.log("Test Failed as Intialize with readme file checkbox not present");
		}
	}

	public boolean validateCreatedRepoDetails()
	{
		boolean result=false;
		try
		{
			WebElement repName=driver.findElement(createdRepositoryName);
			if(repName.getText().equals("NewRepoUnbxd"))
			{
				Reporter.log("Repository name matches input name as expected.");
				result=true;
			}
			else
			{
				Reporter.log("Test Failed as Created Repository name does not match expected name");
				result=false;
			}
		}
		catch(NoSuchElementException NSEE)
		{
		Reporter.log("Test Failed as Created Repository name does not match expected name");
		return false;
		}
		return result;
	}

	public void clickSettingsButton()
	{
		try
		{
			driver.findElement(repoSettingsButton).click();
		}
		catch(NoSuchElementException NSEE)
		{
		Reporter.log("Test Failed as Repository settings button not present");
		}
	}

	public void ClickDeleteRepoButton()
	{
		try
		{
			scrollToElement(driver,driver.findElement(repoDeleteButton));
			driver.findElement(repoDeleteButton).click();
		}
		catch(NoSuchElementException NSEE)
		{
		Reporter.log("Test Failed as Repository delete button not present");
		}
	}

	public void navigateToRepositoryPage(String Repo_name) throws FileNotFoundException, IOException
	{
		String repoName=readData(Repo_name,inputFileName);
		repoListingName=By.xpath("//ul[contains(@id,\"repo_listing\")]//span[contains(text(),'"+repoName+"')]");
		driver.findElement(repoListingName).click();
	}
	
	public void clickNewIssueDropDownButton()
	{
		Actions action=new Actions(driver);
		try
		{
		action.moveToElement(driver.findElement(createIssueDropDownBtn));
		action.perform();
		action.click(driver.findElement(createIssueDropDownBtn));
		action.perform();
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test failed as create or create issue buttons not present");
		}
	}
	
	public void addAttachmentToIssue(String imageNameProp) throws FileNotFoundException, IOException
	{
		String imageName=readData(imageNameProp,inputFileName);
		this.imageName=imageName;
		driver.findElement(inputImageFile).sendKeys(System.getProperty("user.dir")+"\\src\\com\\gitTest\\InputFiles\\Accenture_building.jpg");
	}
	
	public void enterIssueTitle(String title) throws FileNotFoundException, IOException
	{
		try
		{
		String issueTitle=readData(title,inputFileName);
		this.issueTitle=issueTitle;
		driver.findElement(issueTitleLocator).sendKeys(issueTitle);
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test Failed as the Issue title field not present");
			throw new RuntimeException("Issue Name field not interactable");
		}
	}
	
	public Boolean checkIfImageUploaded(String imageFileNameProp) throws FileNotFoundException, IOException, InterruptedException
	{
		Thread.sleep(5000);
		driver.findElement(previewButton).click();
		if(driver.findElement(issueTextArea).getAttribute("alt").contains(imageName.toLowerCase()))
		{
			Reporter.log("The Issue text area contains image name as expected");
			return true;
		}
		else
		{
			Reporter.log("Test failed as the Issue text area does not contain image name of image file");
			return false;
		}
	}
	
	public void submitIssue() throws InterruptedException
	{
		Thread.sleep(8000);
		scrollToElement(driver,driver.findElement(submitIssueBtn));
		driver.findElement(submitIssueBtn).click();
	}

	public boolean checkIfIssueCreatedWithCorrectDetails()
	{
		boolean result=false;
		try{
			if(driver.findElement(newIssueTitle).getText().equals(issueTitle))
			{
				Reporter.log("Issue title verified.");
				if(driver.findElement(newIssueImage).getAttribute("alt").toString().equals(imageName.toLowerCase()))
				{
					Reporter.log("Issue related image verified.");
					Reporter.log("Issue created successfully.");
					result=true;
				}
				else
				{
					Reporter.log("Test failed as uploaded image not attached to issue");
					result=false;
				}
			}
			else
			{
				Reporter.log("Test failed as Issue title not correct");
				result=false;
			}
			}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test failed as issue not created as expected");
			return false;
		}
		return result;
	}

	public void confirmDelete(String Repo_name) throws FileNotFoundException, IOException
	{
		String repoName=readData(Repo_name,inputFileName);
		driver.findElement(confirmBox).sendKeys(repoName);
		driver.findElement(confirmButton).click();
	}
	
	public void verifyIfRepoDeleted(String Repo_name) throws FileNotFoundException, IOException
	{	
		try
		{
		WebElement deleteMessage=driver.findElement(repoDeletedMessage);
		String repoName=readData(Repo_name,inputFileName);
		if(deleteMessage.getText().contains("Your repository \"SaurabhPSingh/"+repoName+"\" was successfully deleted."))
		{
			Reporter.log("Repository deleted successfully as expected");
		}
		else
		{
			Reporter.log("Test Failed as repository not deleted");
		}
		}
		catch(NoSuchElementException NSEE)
		{
			Reporter.log("Test failed as Repository successful deletion message not present");
		}
	}
	
}
