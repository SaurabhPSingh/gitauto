package com.gitTest.Page;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.gitTest.Library.CommonLibrary;

public class LoginPage extends CommonLibrary
{
	String email,  Password,  userName;
	WebDriver driver;
	String inputFileName="LoginInput.properties";
	
	By navToSignInBtn=By.xpath("//a[contains(text(),'Sign in')]");
	By usernameField=By.id("login_field");
	By passwordField=By.id("password");
	By LoginBtn=By.xpath("//input[contains(@value,'Sign in')]");
	By userImage=By.xpath("//img[contains(@alt,'')]");
	By loggedInUser=By.xpath("//div[contains(text(),'Signed in as')]/strong[contains(text(),'')]");	
	
	public LoginPage(){}
	
	
	public LoginPage(WebDriver driver)
	{
		this.driver=driver;
	}

	
	public void clickNavigateToSignInButton()
	{
		try{
			if(driver.findElement(navToSignInBtn).isEnabled())
			{
				driver.findElement(navToSignInBtn).click();
			}
			else
			{
			Reporter.log("Sign in button not visible");	
			}	
			}
		catch(NoSuchElementException NSEE)
			{
				Reporter.log("Test Execution failed as sign in button not present in page.");
			}	
	}
	
	
	public void enterUserName(String email)
	{
		try{
			if(driver.findElement(usernameField).isEnabled())
			{
				this.email=email;
				//String email=readData("email",inputFileName);
				driver.findElement(usernameField).sendKeys(email);
			}
			else
			{
			Reporter.log("User Name field not visible");	
			}	
			}
		catch(NoSuchElementException NSEE)
			{
				Reporter.log("Test Execution failed as User Name field not present in page.");
			}	
	}
	
	
	public void enterPassword(String passwrd)
	{
		try{
			if(driver.findElement(passwordField).isEnabled())
			{
				this.Password=passwrd;
				//String passwrd=readData("password",inputFileName);
				driver.findElement(passwordField).sendKeys(passwrd);
			}
			else
			{
			Reporter.log("Password field not visible");	
			}	
			}
		catch(NoSuchElementException NSEE)
			{
				Reporter.log("Test Execution failed as Password field not present in page.");
			}	
	}
	
	
	public void clickSignInButton() throws InterruptedException
	{
		try{
			if(driver.findElement(LoginBtn).isDisplayed())
			{
				driver.findElement(LoginBtn).click();
			}
			else
			{
				Reporter.log("Sign in button not visible");
			}	
			}
		catch(NoSuchElementException NSEE)
			{
				Reporter.log("Test Execution failed as sign in button not present in page.");
			}	
	}
	
	
	public boolean checkIfUserLoggedIn() throws FileNotFoundException, IOException
	{
		boolean isLoggedIn=false;
		try{
				driver.findElement(userImage).click();
				String expectedUserName=readData("userName",inputFileName);
				String loggedInUserName=driver.findElement(loggedInUser).getText();
				if(expectedUserName.equals(loggedInUserName) && this.email.equals("saurabhpsingh2424@gmail.com"))
				{
					Reporter.log("User successfully logged in.");				
					isLoggedIn=true;
				}
			}
		catch(NoSuchElementException NSEE)
			{
			if(this.email.equals("saurabhpsingh2424@gmail.com"))
			{
				Reporter.log("Test Execution failed as user not logged in properly or login failed.");
				return false;
			}
			else
			{
				Reporter.log("As expected user not logged in for incorrect credentials");
				return true;
			}
			}
		return isLoggedIn;
		
	}
	
}
