package com.gitTest.TestImplementation;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.Reporter;

import com.gitTest.Page.LoginPage;

public class LoginImplementation extends LoginPage
{

	public void gitLoginTest(WebDriver driver,String email, String Password, String userName) throws InterruptedException, FileNotFoundException, IOException
	{
		LoginPage loginPage=new LoginPage(driver);
		loginPage.clickNavigateToSignInButton();
		loginPage.enterUserName(email);
		loginPage.enterPassword(Password);
		loginPage.clickSignInButton();
		Boolean result=loginPage.checkIfUserLoggedIn();
		Assert.assertTrue(result);
	}
	
}
