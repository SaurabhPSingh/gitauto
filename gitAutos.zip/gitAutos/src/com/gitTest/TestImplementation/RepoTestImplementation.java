package com.gitTest.TestImplementation;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.gitTest.Page.RepoTestPage;

public class RepoTestImplementation extends RepoTestPage
{
	public void CreateRepositoryTest(WebDriver driver) throws FileNotFoundException, IOException, InterruptedException
	{
	SoftAssert softAssert=new SoftAssert();
	RepoTestPage repoTestPage=new RepoTestPage(driver);
	repoTestPage.loginToApplication(driver);
	repoTestPage.clickCreateButton();
	repoTestPage.clickCreateRepoLink();
	repoTestPage.enterRepositoryName("Repo_name");
	repoTestPage.verifyIfRepoNameAccepted();
	repoTestPage.checkInitializeWithReadMeCheckBox();
	repoTestPage.clickTheCreateRepositoryButton();
	Boolean result=repoTestPage.validateCreatedRepoDetails();
	softAssert.assertTrue(result,"");
	softAssert.assertAll();
	
	
	}
	
	public void CreateIssueTest(WebDriver driver) throws FileNotFoundException, IOException, InterruptedException
	{
		SoftAssert softAssert=new SoftAssert();
		RepoTestPage repoTestPage=new RepoTestPage(driver);
		repoTestPage.loginToApplication(driver);
		repoTestPage.navigateToRepositoryPage("Repo_name");
		repoTestPage.clickCreateButton();
		repoTestPage.clickNewIssueDropDownButton();
		repoTestPage.enterIssueTitle("Issue1_Title");
		repoTestPage.addAttachmentToIssue("Image_Name");
		boolean result1=repoTestPage.checkIfImageUploaded("Image_Name");
		repoTestPage.submitIssue();
		boolean result2=repoTestPage.checkIfIssueCreatedWithCorrectDetails();
		softAssert.assertTrue(result1, "");
		softAssert.assertTrue(result2, "");
		softAssert.assertAll();
	}

	public void deleteRepositoryTest(WebDriver driver) throws FileNotFoundException, InterruptedException, IOException
	{
		SoftAssert softAssert=new SoftAssert();
		RepoTestPage repoTestPage=new RepoTestPage(driver);
		repoTestPage.loginToApplication(driver);
		repoTestPage.navigateToRepositoryPage("Repo_name");
		repoTestPage.clickSettingsButton();
		repoTestPage.ClickDeleteRepoButton();
		repoTestPage.confirmDelete("Repo_name");
		repoTestPage.verifyIfRepoDeleted("Repo_name");
	}
	
}
